# Guru AI - Android Setup Guide (Hindi & English)

Guru AI ek complete **Offline Local Memory + Online Google Gemini API** Android Assistant hai.

---

## 3 Core Features Jo Is Code Me Shamil Hain:

1. **Local Memory (Room Database)**:
   - User ke chats, shared documents aur facts SQLite / Room database me phone ke andar store hote hain.
   - Offline hone par bhi AI ko purani baatein yaad rehti hain.
   - Koi data third-party server par nahi jata.

2. **Google Gemini API Integration**:
   - Internet hone par direct Google Gemini ke free endpoint par call jati hai:
     `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=YOUR_KEY`
   - Free Gemini API key pane ke liye: [https://aistudio.google.com/](https://aistudio.google.com/) par jayein.

3. **File & Text Sharing (DeepLink Activity)**:
   - Chrome, WhatsApp, Acrobat ya kisi bhi doosri app se share kiye gaye text, PDFs, ya images ko direct accept karta hai (`ACTION_SEND`, `ACTION_SEND_MULTIPLE`, `ACTION_PROCESS_TEXT`).

---

## Android Studio Me Kaise Run Karein:

1. **New Project banayein**:
   - Android Studio kholein -> **New Project** -> **Empty Activity (Compose)** select karein.
   - Package name: `com.example.guruai`

2. **Dependencies add karein**:
   - `build.gradle.kts (app)` file me di gayi dependencies (Room, Retrofit, Coroutines) paste karein.
   - Project sync karein (Sync Now).

3. **Gemini API Key set karein**:
   - `build.gradle.kts` ke andar `buildConfigField` me apni free Gemini key daalein ya `local.properties` me daalein.

4. **Code copy karein**:
   - `AndroidManifest.xml`, `data/local/`, `data/remote/`, aur `ui/` folders ke code ko paste karein.

5. **Run**:
   - Phone ko USB debugging se connect karein ya Emulator start karke **Run** dabayein!
