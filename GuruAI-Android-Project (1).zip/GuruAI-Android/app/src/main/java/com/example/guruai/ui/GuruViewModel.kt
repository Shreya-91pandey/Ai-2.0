package com.example.guruai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.guruai.data.local.ChatMessageEntity
import com.example.guruai.data.local.MemoryNoteEntity
import com.example.guruai.data.repository.GuruRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class GuruUiState(
    val messages: List<ChatMessageEntity> = emptyList(),
    val memories: List<MemoryNoteEntity> = emptyList(),
    val isLoading: Boolean = false,
    val isOnline: Boolean = true,
    val errorMessage: String? = null,
    val pendingSharedText: String? = null,
    val pendingSharedUri: String? = null,
    val pendingMimeType: String? = null
)

class GuruViewModel(
    private val repository: GuruRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(GuruUiState())
    val uiState: StateFlow<GuruUiState> = _uiState.asStateFlow()

    init {
        checkConnectivity()

        // Observe Local Room DB Messages reactively
        viewModelScope.launch {
            repository.allMessages.collect { list ->
                _uiState.update { it.copy(messages = list) }
            }
        }

        // Observe Local Room DB Memories
        viewModelScope.launch {
            repository.allMemories.collect { memList ->
                _uiState.update { it.copy(memories = memList) }
            }
        }
    }

    fun checkConnectivity() {
        _uiState.update { it.copy(isOnline = repository.isOnline()) }
    }

    fun onIncomingSharedContent(text: String?, uriString: String?, mimeType: String?) {
        _uiState.update {
            it.copy(
                pendingSharedText = text,
                pendingSharedUri = uriString,
                pendingMimeType = mimeType
            )
        }
    }

    fun clearPendingShare() {
        _uiState.update {
            it.copy(
                pendingSharedText = null,
                pendingSharedUri = null,
                pendingMimeType = null
            )
        }
    }

    fun sendPrompt(prompt: String) {
        val uri = _uiState.value.pendingSharedUri
        val mime = _uiState.value.pendingMimeType
        clearPendingShare()

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val result = repository.sendMessage(
                userPrompt = prompt,
                fileUri = uri,
                fileMimeType = mime
            )
            result.onFailure { error ->
                _uiState.update { it.copy(errorMessage = error.localizedMessage) }
            }
            _uiState.update { it.copy(isLoading = false) }
        }
    }

    fun addManualMemory(title: String, fact: String, category: String = "fact") {
        viewModelScope.launch {
            repository.saveNoteMemory(title, fact, category)
        }
    }
}