package com.example.guruai.data.remote

import com.google.gson.annotations.SerializedName

// Request models
data class GeminiRequest(
    val contents: List<Content>,
    val systemInstruction: SystemInstruction? = null,
    val generationConfig: GenerationConfig? = GenerationConfig()
)

data class SystemInstruction(
    val parts: List<Part>
)

data class Content(
    val role: String? = null, // "user" or "model"
    val parts: List<Part>
)

data class Part(
    val text: String? = null,
    val inlineData: InlineData? = null
)

data class InlineData(
    @SerializedName("mime_type")
    val mimeType: String,
    val data: String // Base64-encoded string
)

data class GenerationConfig(
    val temperature: Float = 0.7f,
    val topK: Int = 40,
    val topP: Float = 0.95f
)

// Response models
data class GeminiResponse(
    val candidates: List<Candidate>? = null,
    val error: GeminiError? = null
)

data class Candidate(
    val content: Content? = null,
    val finishReason: String? = null
)

data class GeminiError(
    val code: Int,
    val message: String,
    val status: String
)