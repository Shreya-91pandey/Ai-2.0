package com.example.guruai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Stores full conversation history in SQLite on the user's phone.
 * Allows Guru AI to remember past questions and context completely offline.
 */
@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val role: String, // "user" or "guru"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val source: String = "local_db", // "gemini-flash" or "local_memory"
    val attachmentUri: String? = null,
    val attachmentMimeType: String? = null,
    val attachmentName: String? = null
)