package com.example.guruai.ui.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Sparkles
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.guruai.data.local.GuruDatabase
import com.example.guruai.data.remote.GeminiApiService
import com.example.guruai.data.repository.GuruRepository
import kotlinx.coroutines.launch

/**
 * Modern Kotlin transformation of Claude/Android AssistantOverlayActivity (classes3.dex: AssistantOverlayActivity, b41, a41).
 * Registered in AndroidManifest.xml for:
 * - android.intent.action.ASSIST
 * - android.intent.action.VOICE_ASSIST
 *
 * Configured with:
 * taskAffinity="com.example.guruai.assist", launchMode="singleInstance", excludeFromRecents=true, finishOnTaskLaunch=true
 *
 * Renders a floating Jetpack Compose bottom sheet with 28dp top radius and 50% dimmed scrim
 * directly over whatever app the user is currently using (Chrome, YouTube, etc.).
 */
class AssistantOverlayActivity : ComponentActivity() {

    private val repository by lazy {
        val db = GuruDatabase.getInstance(applicationContext)
        val api = GeminiApiService.create()
        GuruRepository(applicationContext, db.guruDao(), api)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            AssistantOverlayScreen(
                onDismiss = { finish() },
                onSendQuery = { query, onResult ->
                    kotlinx.coroutines.GlobalScope.launch {
                        val res = repository.sendMessage(query)
                        onResult(res.getOrNull() ?: "Error")
                    }
                }
            )
        }
    }
}

@Composable
fun AssistantOverlayScreen(
    onDismiss: () -> Unit,
    onSendQuery: (String, (String) -> Unit) -> Unit
) {
    var queryText by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    var aiReply by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    // Scrim background (50% dimmed, taps outside dismiss overlay)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            ),
        contentAlignment = Alignment.BottomCenter
    ) {
        // Floating Sheet with 28dp top corners (matching smali: 28.0f top corners)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { /* absorb clicks */ }
                ),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                // Header handle & title
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .width(40.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Sparkles,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Guru AI Assistant",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Ask anything about what is on your screen or speak a question.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (aiReply != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = aiReply!!,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(14.dp),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Input Box + Voice Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = queryText,
                        onValueChange = { queryText = it },
                        placeholder = { Text("Ask Guru AI...") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(20.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { isListening = !isListening },
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondaryContainer
                        )
                    ) {
                        Icon(Icons.Rounded.Mic, contentDescription = "Voice Input")
                    }

                    if (queryText.isNotBlank()) {
                        Spacer(modifier = Modifier.width(4.dp))
                        IconButton(
                            onClick = {
                                val text = queryText
                                queryText = ""
                                isLoading = true
                                onSendQuery(text) { result ->
                                    aiReply = result
                                    isLoading = false
                                }
                            },
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(Icons.Rounded.Send, contentDescription = "Send")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}
