package com.example.guruai.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.guruai.R
import com.example.guruai.ui.MainActivity
import com.example.guruai.ui.assistant.AssistantOverlayActivity
import com.example.guruai.service.BellModeService

/**
 * GuruAppWidgetProvider
 * Reconstructed from Claude APK <appwidget-provider> targetCellWidth="5", targetCellHeight="2".
 * Provides 1-tap tactile homescreen access to Voice, Search, and Local Room notes.
 */
class GuruAppWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    private fun updateAppWidget(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int
    ) {
        val views = RemoteViews(context.packageName, R.layout.widget_guru_quick_chat)

        // 1. Click on Widget Root -> Open Guru AI Main Activity
        val openAppIntent = Intent(context, MainActivity::class.java)
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_container, openAppPendingIntent)

        // 2. Click on Mic Icon -> Direct Hands-Free Voice Mode
        val voiceIntent = Intent(context, BellModeService::class.java).apply {
            action = BellModeService.ACTION_START_VOICE
        }
        val voicePendingIntent = PendingIntent.getForegroundService(
            context,
            1,
            voiceIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_mic_button, voicePendingIntent)

        // 3. Click on Sparkle / Assist Icon -> Quick Floating Assistant
        val assistIntent = Intent(context, AssistantOverlayActivity::class.java)
        val assistPendingIntent = PendingIntent.getActivity(
            context,
            2,
            assistIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_sparkle_button, assistPendingIntent)

        appWidgetManager.updateAppWidget(appWidgetId, views)
    }
}