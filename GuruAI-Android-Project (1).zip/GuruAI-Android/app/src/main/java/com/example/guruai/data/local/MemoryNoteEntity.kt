package com.example.guruai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Long-term memory notes (e.g. user preferences, notes, shared files summaries)
 * that Guru AI loads into context during queries.
 */
@Entity(tableName = "memory_notes")
data class MemoryNoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val factContent: String,
    val category: String, // "preference", "fact", "shared_doc", "todo"
    val createdAt: Long = System.currentTimeMillis(),
    val source: String = "user_input" // "user_input" or "deeplink_share"
)