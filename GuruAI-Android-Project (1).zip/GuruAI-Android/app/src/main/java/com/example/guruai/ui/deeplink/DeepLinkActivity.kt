package com.example.guruai.ui.deeplink

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.guruai.ui.MainActivity

/**
 * Modern Kotlin transformation of the decompiled Claude/Android DeepLinkActivity (classes3.dex).
 * Implements hardened intent forwarding with:
 * 1. Sanitization of Intent Flags (stripping receiver & forward flags, adding NEW_TASK | CLEAR_TOP | SINGLE_TOP).
 * 2. Unparceling crash defense: Sweeps extras key-by-key in try-catch to remove malformed/corrupted Parcelables.
 * 3. SecurityException URI permission fallback: If sharing URI throws SecurityException, automatically drops
 *    the attachment, retains EXTRA_TEXT, tags EXTRA_SHARE_ATTACHMENT_DROPPED = true, and retries.
 * 4. DeepLink / Universal link routing: Safely inspects ACTION_VIEW, Uri scheme, and universal links.
 */
class DeepLinkActivity : Activity() {

    companion object {
        private const val TAG = "GuruDeepLinkActivity"

        // Smali constant: R = { SEND_MULTIPLE, PROCESS_TEXT, SEND }
        val SHARE_ACTIONS = setOf(
            Intent.ACTION_SEND,
            Intent.ACTION_SEND_MULTIPLE,
            Intent.ACTION_PROCESS_TEXT
        )
        const val EXTRA_SHARE_ATTACHMENT_DROPPED = "com.example.guruai.intent.extra.SHARE_ATTACHMENT_DROPPED"
        const val EXTRA_SHORTCUT_TYPE = "EXTRA_SHORTCUT_TYPE"
        const val EXTRA_QUICK_ACTION = "com.example.guruai.intent.extra.QUICK_ACTION"

        /**
         * Cleans dangerous flags and sets safe activity launch flags.
         * Decompiled Smali method: DeepLinkActivity.p(Intent)
         */
        fun sanitizeIntentFlags(intent: Intent) {
            // 0x8000000 = FLAG_RECEIVER_FOREGROUND
            // 0x80000 = FLAG_RECEIVER_REGISTERED_ONLY
            // 0x1000 = FLAG_ACTIVITY_FORWARD_RESULT
            intent.removeFlags(0x8000000 or 0x80000 or 0x1000)

            // 0x10000000 = FLAG_ACTIVITY_NEW_TASK
            // 0x4000000 = FLAG_ACTIVITY_CLEAR_TOP
            // 0x20000000 = FLAG_ACTIVITY_SINGLE_TOP
            intent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        processIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent?.let { processIntent(it) }
    }

    private fun processIntent(incomingIntent: Intent) {
        // Check if universal deep link (http/https ACTION_VIEW)
        if (handleUniversalLink(incomingIntent)) {
            return
        }

        // Handle Shortcut / Widget actions (smali v() & w() methods)
        handleQuickActions(incomingIntent)

        // Build safe sanitized forwarding intent for MainActivity (smali r() method)
        val sanitizedIntent = buildSanitizedForwardIntent(incomingIntent)

        // Launch with SecurityException fallback for URI permissions (smali u() & t() methods)
        startForwardActivitySafely(sanitizedIntent)
        finish()
    }

    /**
     * Replicates Smali method: q() - Universal Link & Http/Https inspection
     */
    private fun handleUniversalLink(intent: Intent): Boolean {
        if (intent.action != Intent.ACTION_VIEW) return false
        val uri = intent.data ?: return false
        val scheme = uri.scheme?.lowercase() ?: return false
        if (scheme != "http" && scheme != "https") return false

        // Check universal links fragment
        if (uri.fragment == "no_universal_links") {
            val appReferrer = referrer
            if (appReferrer != null && appReferrer.scheme == "android-app" && appReferrer.host == packageName) {
                // Internal referrer, allowed
            } else {
                moveTaskToBack(true)
            }
            finish()
            return true
        }
        return false
    }

    /**
     * Replicates Smali method: r() - Unparceling sweep to avoid BadParcelableException
     */
    private fun buildSanitizedForwardIntent(sourceIntent: Intent): Intent {
        val extras = sourceIntent.extras
        if (extras != null) {
            val sanitizedBundle = Bundle(extras)
            val keyList = extras.keySet().toList()
            var droppedCount = 0

            for (key in keyList) {
                try {
                    // Probe unparceling
                    sanitizedBundle.get(key)
                } catch (t: Throwable) {
                    Log.w(TAG, "Dropping corrupted parcelable extra key: $key", t)
                    sanitizedBundle.remove(key)
                    droppedCount++
                }
            }
            sourceIntent.replaceExtras(sanitizedBundle)
        }

        val forward = Intent(sourceIntent).apply {
            component = ComponentName(this@DeepLinkActivity, MainActivity::class.java)
            removeExtra(EXTRA_SHARE_ATTACHMENT_DROPPED)
            sanitizeIntentFlags(this)
        }
        return forward
    }

    /**
     * Replicates Smali method: u(Intent) & t(Exception, int)
     * Handles SecurityException when sharing files from other apps
     */
    private fun startForwardActivitySafely(forwardIntent: Intent) {
        try {
            startActivity(forwardIntent)
        } catch (e: Exception) {
            val action = forwardIntent.action
            if (action in SHARE_ACTIONS) {
                Log.w(TAG, "Primary share forward failed; applying attachment stripping fallback", e)

                // If ACTION_SEND and has stream or clip data
                val hasStream = forwardIntent.hasExtra(Intent.EXTRA_STREAM)
                val clipData = forwardIntent.clipData
                val hasClipUri = clipData != null && (0 until clipData.itemCount).any { clipData.getItemAt(it).uri != null }

                val text = forwardIntent.getCharSequenceExtra(Intent.EXTRA_TEXT)

                // Fallback: If text exists, strip Uri/Stream and retry
                if ((hasStream || hasClipUri) && !text.isNullOrBlank()) {
                    try {
                        val strippedIntent = Intent(forwardIntent).apply {
                            removeExtra(Intent.EXTRA_STREAM)
                            setClipData(null)
                            removeFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                            putExtra(EXTRA_SHARE_ATTACHMENT_DROPPED, true)
                        }
                        startActivity(strippedIntent)
                        return
                    } catch (e2: Exception) {
                        Log.e(TAG, "Stripped share fallback also failed", e2)
                    }
                }

                // Final fallback: open clean MainActivity and inform user
                val cleanIntent = Intent(this, MainActivity::class.java).apply {
                    sanitizeIntentFlags(this)
                }
                startActivity(cleanIntent)
                Toast.makeText(applicationContext, "Unable to access shared file", Toast.LENGTH_SHORT).show()
            } else {
                throw e
            }
        }
    }

    private fun handleQuickActions(intent: Intent) {
        val quickAction = intent.getStringExtra(EXTRA_QUICK_ACTION)
        val shortcutType = intent.getStringExtra(EXTRA_SHORTCUT_TYPE)
        if (quickAction != null || shortcutType != null) {
            Log.d(TAG, "Widget/Shortcut action tapped: action=$quickAction, type=$shortcutType")
        }
    }
}