package com.example.guruai.util

import android.app.Activity
import android.os.Build
import android.util.Log

/**
 * ScreenCaptureDetector
 * Implements Android 14 (API 34) Activity.ScreenCaptureCallback
 * Uses permission: <uses-permission android:name="android.permission.DETECT_SCREEN_CAPTURE" />
 * 
 * When user takes a screenshot of their phone, Guru AI can proactively offer:
 * "Screenshot detected! Would you like me to analyze it with Gemini Flash?"
 */
class ScreenCaptureDetector(
    private val activity: Activity,
    private val onScreenCaptured: () -> Unit
) {
    private var isRegistered = false

    private val captureCallback = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        Activity.ScreenCaptureCallback {
            Log.d("ScreenCaptureDetector", "Screenshot event captured by Android OS")
            onScreenCaptured()
        }
    } else null

    fun register() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && !isRegistered) {
            captureCallback?.let {
                try {
                    activity.registerScreenCaptureCallback(activity.mainExecutor, it)
                    isRegistered = true
                } catch (e: SecurityException) {
                    Log.w("ScreenCaptureDetector", "Permission DETECT_SCREEN_CAPTURE not granted", e)
                }
            }
        }
    }

    fun unregister() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && isRegistered) {
            captureCallback?.let {
                try {
                    activity.unregisterScreenCaptureCallback(it)
                } catch (e: Exception) {
                    Log.w("ScreenCaptureDetector", "Error unregistering callback", e)
                }
            }
            isRegistered = false
        }
    }
}