package com.example.guruai.data.health

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant
import java.time.temporal.ChronoUnit

/**
 * HealthConnectManager
 * Bridges Android Health Connect API (android.permission.health.READ_STEPS, READ_HEART_RATE, READ_SLEEP)
 * Allows Guru AI to answer health queries with accurate personal wellness context securely on-device.
 */
class HealthConnectManager(private val context: Context) {

    private val healthConnectClient by lazy {
        if (HealthConnectClient.isProviderAvailable(context)) {
            HealthConnectClient.getOrCreate(context)
        } else null
    }

    val permissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class)
    )

    suspend fun hasPermissions(): Boolean {
        val client = healthConnectClient ?: return false
        val granted = client.permissionController.getGrantedPermissions()
        return granted.containsAll(permissions)
    }

    /**
     * Reads steps walked in the past 24 hours
     */
    suspend fun getTodaySteps(): Long {
        val client = healthConnectClient ?: return 0L
        return try {
            val startTime = Instant.now().minus(24, ChronoUnit.HOURS)
            val endTime = Instant.now()
            val response = client.readRecords(
                ReadRecordsRequest(
                    recordType = StepsRecord::class,
                    timeRangeFilter = TimeRangeFilter.between(startTime, endTime)
                )
            )
            response.records.sumOf { it.count }
        } catch (e: Exception) {
            0L
        }
    }

    /**
     * Generates a context summary for Gemini Flash prompt
     */
    suspend fun getHealthSummary(): String {
        if (!hasPermissions()) return "Health Connect permissions not granted."
        val steps = getTodaySteps()
        return "Today Steps: $steps steps (via Android Health Connect)"
    }
}