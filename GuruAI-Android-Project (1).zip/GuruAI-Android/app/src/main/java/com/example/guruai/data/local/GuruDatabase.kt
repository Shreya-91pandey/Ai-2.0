package com.example.guruai.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ChatMessageEntity::class, MemoryNoteEntity::class],
    version = 1,
    exportSchema = false
)
abstract class GuruDatabase : RoomDatabase() {
    abstract fun guruDao(): GuruDao

    companion object {
        @Volatile
        private var INSTANCE: GuruDatabase? = null

        fun getInstance(context: Context): GuruDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GuruDatabase::class.java,
                    "guru_ai_local_memory.db"
                ).fallbackToDestructiveMigration()
                 .build()
                INSTANCE = instance
                instance
            }
        }
    }
}