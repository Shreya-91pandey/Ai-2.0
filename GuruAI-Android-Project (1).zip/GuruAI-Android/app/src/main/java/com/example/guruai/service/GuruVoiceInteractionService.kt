package com.example.guruai.service

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import com.example.guruai.R
import com.example.guruai.ui.assistant.AssistantOverlayActivity

/**
 * GuruVoiceInteractionService
 * Decompiled & reconstructed from Claude classes3.dex system voice assistant.
 * 
 * When set as default digital assistant in Android Settings -> Apps -> Default apps -> Digital Assistant:
 * - Listens for system assistant invocations (e.g. power button hold, swipe from corner)
 * - Captures AssistStructure (screen content hierarchy) and AssistContent (active Chrome URLs)
 * - Directly streams context into Gemini Flash API
 */
class GuruVoiceInteractionService : VoiceInteractionService() {

    override fun onReady() {
        super.onReady()
        // Assistant service is bound and ready to handle system invocations
    }

    override fun onShutdown() {
        super.onShutdown()
    }
}

/**
 * Manages the floating assistant session lifecycle when invoked by system gesture
 */
class GuruVoiceSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        return GuruAssistantSession(this)
    }
}

class GuruAssistantSession(context: Context) : VoiceInteractionSession(context) {

    override fun onCreate() {
        super.onCreate()
    }

    override fun onHandleAssist(
        data: Bundle?,
        structure: android.app.assist.AssistStructure?,
        content: android.app.assist.AssistContent?
    ) {
        super.onHandleAssist(data, structure, content)

        // 1. Extract Current Browser / App URL if available
        val webUri = content?.webUri?.toString()

        // 2. Launch floating Compose overlay with active screen context
        val intent = Intent(context, AssistantOverlayActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_CAPTURED_URL", webUri)
            putExtra("EXTRA_INVOCATION_TYPE", "SYSTEM_VOICE_KEY")
        }
        context.startActivity(intent)

        // Close transient voice session window
        hide()
    }
}