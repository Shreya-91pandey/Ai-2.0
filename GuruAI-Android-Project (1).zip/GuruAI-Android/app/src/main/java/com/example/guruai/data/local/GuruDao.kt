package com.example.guruai.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GuruDao {
    // --- Chat Messages ---
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessagesFlow(): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentMessages(limit: Int = 10): List<ChatMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearAllMessages()

    // --- Long-Term Memories & Facts ---
    @Query("SELECT * FROM memory_notes ORDER BY createdAt DESC")
    fun getAllMemoriesFlow(): Flow<List<MemoryNoteEntity>>

    @Query("SELECT * FROM memory_notes ORDER BY createdAt DESC LIMIT :limit")
    suspend fun getRecentMemories(limit: Int = 10): List<MemoryNoteEntity>

    @Query("SELECT * FROM memory_notes WHERE factContent LIKE '%' || :query || '%' OR title LIKE '%' || :query || '%'")
    suspend fun searchMemories(query: String): List<MemoryNoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryNoteEntity): Long

    @Delete
    suspend fun deleteMemory(memory: MemoryNoteEntity)
}