package com.example.guruai.data.repository

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Base64
import com.example.guruai.BuildConfig
import com.example.guruai.data.local.*
import com.example.guruai.data.remote.*
import kotlinx.coroutines.flow.Flow
import java.io.InputStream

class GuruRepository(
    private val context: Context,
    private val guruDao: GuruDao,
    private val apiService: GeminiApiService
) {
    val allMessages: Flow<List<ChatMessageEntity>> = guruDao.getAllMessagesFlow()
    val allMemories: Flow<List<MemoryNoteEntity>> = guruDao.getAllMemoriesFlow()

    fun isOnline(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun sendMessage(
        userPrompt: String,
        fileUri: String? = null,
        fileMimeType: String? = null,
        fileName: String? = null
    ): Result<String> {
        // 1. Persist User message immediately in Local Room Database
        val userEntity = ChatMessageEntity(
            role = "user",
            content = userPrompt,
            source = "local_db",
            attachmentUri = fileUri,
            attachmentMimeType = fileMimeType,
            attachmentName = fileName
        )
        guruDao.insertMessage(userEntity)

        // 2. If Offline: Use phone local memory to answer
        if (!isOnline()) {
            val matchingMemories = guruDao.searchMemories(userPrompt)
            val offlineReply = if (matchingMemories.isNotEmpty()) {
                val memoryInfo = matchingMemories.joinToString("; ") { "${it.title}: ${it.factContent}" }
                "[Guru AI - Offline Memory]: Phone ke local database me aapki purani baatein mili: $memoryInfo."
            } else {
                "[Guru AI - Offline Mode]: Internet band hai. Aapka message phone ke SQLite memory me save kar liya gaya hai. Online aate hi poora jawab mil jayega."
            }

            guruDao.insertMessage(
                ChatMessageEntity(
                    role = "guru",
                    content = offlineReply,
                    source = "offline_local_db"
                )
            )
            return Result.success(offlineReply)
        }

        // 3. If Online: Read top local memories to build Context-Aware Prompt
        val recentMemories = guruDao.getRecentMemories(5)
        val memoryContext = if (recentMemories.isNotEmpty()) {
            recentMemories.joinToString("\n") { "- [${it.category}] ${it.title}: ${it.factContent}" }
        } else {
            "No prior facts recorded."
        }

        val systemInstructionText = """
            You are "Guru AI", a smart personal assistant on the user's Android phone.
            You respect user privacy by storing memories in their phone's local Room database.
            Use this phone local memory context to personalize your answer:
            $memoryContext
            
            Answer politely and smartly in the language user speaks (Hindi/Hinglish or English).
        """.trimIndent()

        // 4. Prepare Gemini Parts
        val parts = mutableListOf<Part>()
        
        // If file attachment exists (Image or PDF)
        if (fileUri != null && fileMimeType != null) {
            val base64Data = readUriAsBase64(fileUri)
            if (base64Data != null) {
                parts.add(Part(inlineData = InlineData(mimeType = fileMimeType, data = base64Data)))
            }
        }
        parts.add(Part(text = userPrompt))

        val request = GeminiRequest(
            contents = listOf(Content(role = "user", parts = parts)),
            systemInstruction = SystemInstruction(listOf(Part(text = systemInstructionText)))
        )

        return try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            val response = apiService.generateContent(apiKey, request)

            if (response.isSuccessful && response.body() != null) {
                val replyText = response.body()?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: "Koi jawab praapt nahi hua."

                // Save Gemini answer to local Room DB
                guruDao.insertMessage(
                    ChatMessageEntity(
                        role = "guru",
                        content = replyText,
                        source = "gemini-flash"
                    )
                )

                Result.success(replyText)
            } else {
                val errorMsg = response.errorBody()?.string() ?: "Gemini API Error (${response.code()})"
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveNoteMemory(title: String, fact: String, category: String) {
        guruDao.insertMemory(
            MemoryNoteEntity(
                title = title,
                factContent = fact,
                category = category,
                source = "user_input"
            )
        )
    }

    private fun readUriAsBase64(uriString: String): String? {
        return try {
            val uri = android.net.Uri.parse(uriString)
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val bytes = inputStream?.readBytes()
            inputStream?.close()
            if (bytes != null) Base64.encodeToString(bytes, Base64.NO_WRAP) else null
        } catch (e: Exception) {
            null
        }
    }
}