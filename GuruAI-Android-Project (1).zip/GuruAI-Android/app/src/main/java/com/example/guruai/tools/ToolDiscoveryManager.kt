package com.example.guruai.tools

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle

data class DeviceTool(
    val id: String,
    val name: String,
    val description: String,
    val packageName: String,
    val actionName: String
)

/**
 * ToolDiscoveryManager
 * Implements Android queryIntentServices:
 * <intent><action android:name="com.example.guruai.tool.DISCOVER_TOOLS"/></intent>
 * 
 * Allows third-party Android apps on the phone to expose Tools/Plugins to Guru AI
 * (e.g. Flashlight, Alarm, Calendar, WhatsApp automation) via Android IPC!
 */
class ToolDiscoveryManager(private val context: Context) {

    companion object {
        const val ACTION_DISCOVER = "com.example.guruai.tool.DISCOVER_TOOLS"
        const val ACTION_EXECUTE = "com.example.guruai.tool.EXECUTE_TOOL"
    }

    fun discoverInstalledTools(): List<DeviceTool> {
        val packageManager = context.packageManager
        val intent = Intent(ACTION_DISCOVER)
        val resolveInfos = packageManager.queryIntentServices(intent, PackageManager.GET_META_DATA)

        return resolveInfos.mapNotNull { info ->
            val meta = info.serviceInfo?.metaData ?: return@mapNotNull null
            val toolId = meta.getString("tool_id") ?: info.serviceInfo.name
            val toolName = meta.getString("tool_name") ?: info.loadLabel(packageManager).toString()
            val toolDesc = meta.getString("tool_description") ?: "On-device action tool"

            DeviceTool(
                id = toolId,
                name = toolName,
                description = toolDesc,
                packageName = info.serviceInfo.packageName,
                actionName = ACTION_EXECUTE
            )
        }
    }
}