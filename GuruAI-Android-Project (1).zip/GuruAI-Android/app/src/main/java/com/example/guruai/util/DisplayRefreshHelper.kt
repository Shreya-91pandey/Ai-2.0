package com.example.guruai.util

import android.os.Build
import android.view.Display
import android.view.Window

/**
 * Optimizes display refresh rate up to 120Hz/90Hz.
 * Modern Kotlin transformation of MainActivity.onCreate display mode configuration in Claude classes.dex.
 * Queries Display.supportedModes to pick highest refresh rate for butter-smooth scrolling and voice waveforms.
 */
object DisplayRefreshHelper {

    fun optimizeHighRefreshRate(window: Window) {
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                window.context.display
            } catch (e: Throwable) {
                null
            }
        } else {
            @Suppress("DEPRECATION")
            window.windowManager?.defaultDisplay
        } ?: return

        val modes = display.supportedModes ?: return
        if (modes.isEmpty()) return

        var maxRate = 60.0f
        var bestModeId = 0

        for (mode in modes) {
            if (mode.refreshRate > maxRate) {
                maxRate = mode.refreshRate
                bestModeId = mode.modeId
            }
        }

        if (bestModeId != 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val params = window.attributes
            params.preferredDisplayModeId = bestModeId
            window.attributes = params
        }
    }
}
